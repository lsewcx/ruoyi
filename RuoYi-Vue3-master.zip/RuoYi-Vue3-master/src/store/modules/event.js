import Vue from 'Vue'

const bus =new Vue()
export default bus