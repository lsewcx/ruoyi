package com.ruoyi.system.controller;

public class jiagejisuan {
    public static int zuizhongjiage(int a,int b)
    {
        return a*b;
    }


}
